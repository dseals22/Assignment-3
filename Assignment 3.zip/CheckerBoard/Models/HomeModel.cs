﻿namespace CheckerBoard.Models
{
    public class HomeModel
    {
        public string PageTitle { get; set; }
    }
}