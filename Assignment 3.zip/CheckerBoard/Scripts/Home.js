﻿$(document).ready(function()
{
    var cells = $(".cell");
    var colorCount = 0; 

    for (var i = 0; i < cells.length; i++)
    {
        var cell = $(cells[i]);
        var isDark = colorCount % 2 == 0;
        var isNextRow = (i + 1) % 8 == 0;
        colorCount += isNextRow ? 2 : 1;
        cell.css("background-color", isDark ? "navy" : "white"); 
    }
    $(".cell.piece.red").on({
        click: function () {
            $(this).css("background-color", "yellow"); }
    });
    $(".cell.piece.black").on({
        click: function () {
            $(this).css("background-color", "yellow");  }
    });
    // moves any red checker piece to any spot on the checkerboard 
    $(".piece.red").draggable();
                  
});